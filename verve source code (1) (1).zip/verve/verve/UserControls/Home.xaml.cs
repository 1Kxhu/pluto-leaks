﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Path = System.Windows.Shapes.Path;

namespace verve.UserControls
{
    /// <summary>
    /// Interaction logic for Home.xaml
    /// </summary>
    public partial class Home : UserControl
    {
        public Home()
        {
            InitializeComponent();
            string appdata = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            vervefolder = appdata + "\\verve";
            vervefile = vervefolder + "\\list.txt";

            if (!Directory.Exists(vervefolder))
            {
                _ = Directory.CreateDirectory(vervefolder);
            }
            if (!File.Exists(vervefile))
            {
                File.WriteAllText(vervefile, "");
            }
            checkFavoritesTimer.Interval = TimeSpan.FromSeconds(1);

            checkFavoritesTimer.Tick += (e, s) =>
            {
                if (canCheckFavorites)

                {
                    foreach (Border brd in gamePanel.Children)
                    {
                        bool foundmatch = false;
                        Grid grid = (Grid)brd.Child;
                        Path favortitePath = (Path)grid.Children[4];
                        string tag = (string)brd.Tag;
                        try
                        {
                            vervefolder = appdata + "\\verve";
                            string vervefile2 = vervefolder + "\\list.txt";

                            string[] filetext = File.ReadAllText(vervefile2).Split();


                            for (int i = 0; i < filetext.Length; i++)
                            {
                                string compare1 = filetext[i].ToLower().Replace(" ", "");
                                string compare2 = tag.ToLower().Replace(" ", "");

                                //sorts through every line of the verve list.txt file
                                //if the line's text is equal to the game name, mark foundmatch as true
                                //(file is edited through the addfavorite method thats called upon mouseclick on the button, not through this)

                                if (compare1 == compare2)
                                {
                                    foundmatch = true;
                                }
                            }

                        }
                        catch
                        {
                            favortitePath.Style = (Style)FindResource("favPathHollow");
                        }
                        if (foundmatch)
                        {
                            favortitePath.Style = (Style)FindResource("favPathFilled");
                        }
                        else
                        {
                            favortitePath.Style = (Style)FindResource("favPathHollow");
                        }
                    }
                }
            };

            checkFavoritesTimer.Start();
        }

        DispatcherTimer checkFavoritesTimer = new DispatcherTimer();
        string vervefolder;
        string vervefile;
        bool canCheckFavorites = false;

        private void loadCards()
        {
            templateCard.Visibility = Visibility.Collapsed;

            // usage: createCard(game_name, cover_image_url, run_button_triggered_action)
            createCard("Half-Life 2", "https://cdn.discordapp.com/attachments/972161871513800796/1183469825863995402/HLF2.jpg", halflife2);
            createCard("Among Us", "https://cdn.discordapp.com/attachments/972161871513800796/1183472230085165136/image.png", amongus);
            createCard("Timberman", "https://cdn.discordapp.com/attachments/972161871513800796/1183472442874789908/image.png", null);
            createCard("Clicker Heroes", "https://cdn.discordapp.com/attachments/972161871513800796/1183472637729591306/image.png", null);
        }

        private void halflife2()
        {
            MessageBox.Show("this is for half life 2");
        }

        private void amongus()
        {
            MessageBox.Show("this is for among us");
        }

        private void addFavorite(string tag, Path path)
        {
            canCheckFavorites = false;
            //mostly taken from og verve
            string appdata = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string vervefolder = appdata + "\\verve";
            string vervefile = vervefolder + "\\list.txt";

            if (!Directory.Exists(vervefolder))
            {
                Directory.CreateDirectory(vervefolder);
            }

            if (File.Exists(vervefile))
            {
                string[] filetext = File.ReadAllLines(vervefile);
                int lines = filetext.Length;
                bool foundmatch = false;

                List<string> filetextList = new List<string>(filetext);

                for (int i = 0; i < filetextList.Count; i++)
                {
                    if (filetextList[i] == tag)
                    {
                        filetextList.RemoveAt(i);
                        i--;
                        foundmatch = true;
                        filetext = filetextList.ToArray();
                        filetext = filetext.Where(line => !string.IsNullOrWhiteSpace(line)).ToArray();
                        File.WriteAllLines(vervefile, filetext);
                        break;
                    }
                }

                if (foundmatch == false)
                {

                    File.AppendAllText(vervefile, "\n" + tag);
                }
            }
            else
            {
                File.WriteAllText(vervefile, tag);
            }
            canCheckFavorites = true;
        }

        private void createCard(string game, string coverUrl, Action runButtonAction)
        {
            canCheckFavorites = false;
            //cardClone is a copy of the templateCard you can see in the designer
            Border cardClone = copyTemplateCard();
            cardClone.Margin = new Thickness(2, 2, 2, 2);
            cardClone.Visibility = Visibility.Visible;

            //Getting the controls needed f.e. the game name label, or the cover Image and run button
            Grid grid = (Grid)cardClone.Child;
            Image coverImage = (Image)grid.Children[0];
            Label gameLabel = (Label)grid.Children[1];
            Button runButton = (Button)grid.Children[2];
            Button favoriteButton = (Button)grid.Children[3];

            Path favortitePath = (Path)grid.Children[4];

            string tag;

            //If game arg isn't null assign it a special tag with no spaces
            //(tag was made like this to make searching games easier in mainwindow)
            if (game != null)
            {
                gameLabel.Content = game;
                string specialTag = game.Replace(" ", "");
                tag = specialTag;
                cardClone.Tag = specialTag;
            }
            else
            {
                gameLabel.Content = "Empty name";
                cardClone.Tag = "EmptyName";
                tag = "EmptyName";
            }

            //here is the code that runs the method you specify as runbuttonaction
            if (runButtonAction != null)
            {
                runButton.Click += (e, s) =>
                {
                    runButtonAction();
                };
            }

            //favorite/unfavorite the game
            favoriteButton.Click += (e, s) =>
            {
                canCheckFavorites = false;
                if (favortitePath.Style == (Style)FindResource("favPathFilled"))
                {
                    Application.Current.Dispatcher.Invoke(() =>
                    {

                        favortitePath.Style = (Style)FindResource("favPathHollow");

                    });
                }
                else
                {
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        {
                            favortitePath.Style = (Style)FindResource("favPathFilled");
                        }
                    });
                }
                addFavorite(tag, favortitePath);
                canCheckFavorites = true;
            };

            //favorite/unfavorite the game v2
            favortitePath.MouseDown += (sender, e) =>
            {
                canCheckFavorites = false;
                if (favortitePath.Style == (Style)FindResource("favPathFilled"))
                {
                    Application.Current.Dispatcher.Invoke(() =>
                    {

                        favortitePath.Style = (Style)FindResource("favPathHollow");

                    });
                }
                else
                {
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        {
                            favortitePath.Style = (Style)FindResource("favPathFilled");
                        }
                    });
                }
                addFavorite(tag, favortitePath);
                canCheckFavorites = true;
            };

            //it tries to make a bitmap out of the coverurl argument, if failed, means the url is invalid
            //therefore it catches an exception and assigns it the emptyimage.png from resources
            try
            {
                BitmapImage bitmapImage = new BitmapImage(new Uri(coverUrl));
                coverImage.Source = bitmapImage;
            }
            catch
            {
                coverImage.Source = Imaging.CreateBitmapSourceFromHBitmap(Properties.Resources.EmptyImage.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
            }

            try
            {
                string appdata = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                vervefolder = appdata + "\\verve";
                string vervefile2 = vervefolder + "\\list.txt";

                string[] filetext = File.ReadAllLines(vervefile2);

                for (int i = 0; i < filetext.Length; i++)
                {
                    string compare1 = filetext[i].ToLower().Replace(" ", "");
                    string compare2 = tag.ToLower().Replace(" ", "");

                    //sorts through every line of the verve list.txt file
                    //if the line's text is equal to the game name, change style
                    //(file is edited through the addfavorite method thats called upon mouseclick on the button)

                    if (compare1 == compare2)
                    {
                        Application.Current.Dispatcher.Invoke(() =>
                        {

                            favortitePath.Style = (Style)FindResource("favPathHollow");

                        });
                    }
                    else
                    {
                        Application.Current.Dispatcher.Invoke(() =>
                        {
                            {
                                favortitePath.Style = (Style)FindResource("favPathFilled");
                            }
                        });
                    }
                }
            }
            catch
            {
                favortitePath.Style = (Style)FindResource("favPathHollow");
            }


            //and yeah just adds the new card to the game panel
            gamePanel.Children.Add(cardClone);
            canCheckFavorites = true;
        }

        public Border copyTemplateCard()
        {
            return (Border)XamlReader.Parse(XamlWriter.Save(templateCard));
        }

        private void UserControl_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            gamePanel.Width = Width;
            gamePanel.Height = Height;
        }

        private void UserControl_Initialized(object sender, EventArgs e)
        {
            loadCards();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {


        }
    }
}
