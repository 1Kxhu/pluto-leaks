﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace verve.UserControls
{
    /// <summary>
    /// Logika interakcji dla klasy Settings.xaml
    /// </summary>
    public partial class Settings : UserControl
    {
        DispatcherTimer hourTimer = new DispatcherTimer();
        public static bool showUsername = false;

        string[] welcomeMessages = {
    "Hello, ",
    "What's up, ",
    "Welcome, ",
    "Hi there, ",
    "Greetings, ",
    "Hi there, ",
    "Nice to see you, ",
    "Hey, ",
    "Glad to have you, ",
    "Smile, ",
    "Pleasure having you, ",
};


        public Settings()
        {
            InitializeComponent();
            hourTimer.Interval = TimeSpan.FromSeconds(1);
            hourTimer.Tick += (e, s) =>
            {
                hourLabel.Content = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00");
            };
            hourLabel.Content = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00");
            hourTimer.Start();
        }

        Random rnd = new Random();

        private void welcomeLabel_Loaded(object sender, RoutedEventArgs e)
        {
            int line = rnd.Next(0, welcomeMessages.Length);
            string message = welcomeMessages[line];
            if (showUsername)
            {
                welcomeLabel.Content = message + Environment.UserName + ".";
            }
            else
            {
                welcomeLabel.Content = message + "Verve User" + ".";
            }

            //christmas
            if (DateTime.Now.Month == 12 && DateTime.Now.Day > 22)
            {
                welcomeLabel.Content = "Merry christmas!";
            }

            //st. patrick's day
            if (DateTime.Now.Month == 3 && DateTime.Now.Day > 16 && DateTime.Now.Day < 19)
            {
                welcomeLabel.Content = "Feeling quite lucky today..";
            }

            //new year
            if (DateTime.Now.Month == 1)
            {
                welcomeLabel.Content = "Happy new year!";
            }

            //valentines
            if (DateTime.Now.Month == 2 && DateTime.Now.Day < 16 && DateTime.Now.Day > 12)
            {
                welcomeLabel.Content = "Love from Verve devs!";
            }

            //halloween
            if (DateTime.Now.Month == 10)
            {
                welcomeLabel.Content = "Trick or treat?";
            }

            //yeah you can tell im having way too much fun with this lol
        }

        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {
            //the variable name expains itself
            //basically, there's this label that greets the user called welcomeLabel
            showUsername = !showUsername;
            welcomeLabel_Loaded(sender, e);
        }

        //Appearance tab
        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        //Functionality tab
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }
    }
}
