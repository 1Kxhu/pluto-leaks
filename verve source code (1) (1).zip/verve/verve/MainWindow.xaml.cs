﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;
using verve.UserControls;

namespace verve
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        UserControl home = new Home();
        UserControl settings = new Settings();

        public MainWindow()
        {
            InitializeComponent();
            setContent(home);
            Width = 1333;
            Height = 739;
            var StartupAnim = FindResource("Startup") as Storyboard;
            StartupAnim?.Begin();
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        //game search box
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Grid gameGrid = (Grid)home.FindName("griddy");
            WrapPanel gamelist = (WrapPanel)gameGrid.FindName("gamePanel");

            foreach (var control in gamelist.Children)
            {
                if (control is Border br)
                {
                    //tag and search cleanup for better user experience
                    string tag = (string)br.Tag;
                    tag = tag.ToLower();
                    tag = tag.Replace(" ", "");

                    string search = gameSearcher.Text;
                    search = search.ToLower();
                    search = search.Replace(" ", "");

                    if (tag.Contains(search))
                    {
                        br.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        br.Visibility = Visibility.Collapsed;
                    }
                }
            }
        }

        private void setContent(UserControl uc)
        {
            ucContainer.Child = uc;
            var TabLoadedAnim = FindResource("TabLoaded") as Storyboard;
            TabLoadedAnim?.Begin();
        }

        //home click
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            setContent(home);
            homeBtn.Style = (Style)FindResource("checkedTab");
            settingsBtn.Style = (Style)FindResource("uncheckedTab");
            creditsBtn.Style = (Style)FindResource("uncheckedTab");
        }

        //settings click
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            setContent(settings);
            homeBtn.Style = (Style)FindResource("uncheckedTab");
            settingsBtn.Style = (Style)FindResource("checkedTab");
            creditsBtn.Style = (Style)FindResource("uncheckedTab");
        }

        //credits click
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            setContent(null);
            homeBtn.Style = (Style)FindResource("uncheckedTab");
            settingsBtn.Style = (Style)FindResource("uncheckedTab");
            creditsBtn.Style = (Style)FindResource("checkedTab");
        }

        //close button
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
            Close();
            Application.Current.Shutdown();

        }

        //maximize button
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Maximized)
            {
                WindowState = WindowState.Normal;
            }
            else
            {
                WindowState = WindowState.Maximized;
            }
        }

        //minimize button
        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            ucContainer.Width = Math.Max(Width - 8, 0);
            ucContainer.Height = Math.Max(Height - 8 - 69, 0);
            home.Width = ucContainer.Width;
            home.Height = ucContainer.Height;
        }
    }
}
